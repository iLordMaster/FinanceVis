class NotificationRepository {
  async create(notification) {
    throw new Error('Method not implemented');
  }

  async findByUserId(userId) {
    throw new Error('Method not implemented');
  }

  async findById(id) {
    throw new Error('Method not implemented');
  }

  async markAsRead(id) {
    throw new Error('Method not implemented');
  }

  async markAllAsRead(userId) {
    throw new Error('Method not implemented');
  }

  async deleteById(id) {
    throw new Error('Method not implemented');
  }
}

module.exports = NotificationRepository;
