class TokenService {
  generateToken(payload) {
    throw new Error('Method not implemented');
  }

  verifyToken(token) {
    throw new Error('Method not implemented');
  }
}

module.exports = TokenService;
