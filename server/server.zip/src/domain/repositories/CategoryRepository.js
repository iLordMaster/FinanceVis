class CategoryRepository {
  async create(category) {
    throw new Error('Method not implemented');
  }

  async createMany(categories) {
    throw new Error('Method not implemented');
  }

  async findByUserId(userId) {
    throw new Error('Method not implemented');
  }

  async findAll() {
    throw new Error('Method not implemented');
  }
}

module.exports = CategoryRepository;
